# Build note

The GitHub Actions workflow intentionally builds a **debug APK** first.
This avoids the R8/minify failure that was blocking the release build.

After the APK builds successfully, release/minification can be handled separately.
