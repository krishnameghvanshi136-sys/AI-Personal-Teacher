import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

void main() => runApp(const TeacherApp());

class TeacherApp extends StatelessWidget {
  const TeacherApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AI Personal Teacher',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3F51B5)),
    ),
    home: const HomePage(),
  );
}

const subjects = [
  'Mathematics', 'Science', 'Hindi', 'English', 'Social Science', 'Computer'
];

List<String> chapters(int c) => c <= 5
    ? ['Numbers','Addition & Subtraction','Multiplication','Fractions','Geometry','Measurement']
    : ['Numbers','Fractions & Decimals','Percentage','Algebra','Geometry','Mensuration','Data Handling'];

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AI Personal Teacher'), centerTitle: true),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
        const Icon(Icons.school, size: 60),
        const SizedBox(height: 10),
        const Text('हर बच्चे का Personal Teacher',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center),
        const SizedBox(height: 8),
        const Text('Class 1–10 • Free-first • Privacy-first',
          textAlign: TextAlign.center),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const ClassPage())),
          icon: const Icon(Icons.arrow_forward),
          label: const Text('कक्षा चुनें')),
      ]))),
      const SizedBox(height: 18),
      const ListTile(leading: Icon(Icons.camera_alt), title: Text('Photo → OCR → Confirm')),
      const ListTile(leading: Icon(Icons.mic), title: Text('Voice से सवाल')),
      const ListTile(leading: Icon(Icons.record_voice_over), title: Text('Teacher की आवाज़')),
      const ListTile(leading: Icon(Icons.lock_outline), title: Text('Hindi + English OCR • Photo local processing')),
    ]),
  );
}


class StudentStore {
  static final Map<String, int> scores = {};
  static int attempts = 0;
  static int correct = 0;
  static bool loaded = false;

  static Future<void> load() async {
    if (loaded) return;
    final prefs = await SharedPreferences.getInstance();
    attempts = prefs.getInt('student_attempts') ?? 0;
    correct = prefs.getInt('student_correct') ?? 0;
    final raw = prefs.getStringList('student_scores') ?? <String>[];
    for (final item in raw) {
      final parts = item.split('::');
      if (parts.length == 2) {
        scores[parts[0]] = int.tryParse(parts[1]) ?? 0;
      }
    }
    loaded = true;
  }

  static Future<void> record(String key, bool ok) async {
    await load();
    attempts++;
    if (ok) correct++;
    scores[key] = (scores[key] ?? 0) + (ok ? 1 : 0);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('student_attempts', attempts);
    await prefs.setInt('student_correct', correct);
    await prefs.setStringList(
      'student_scores',
      scores.entries.map((e) => '${e.key}::${e.value}').toList(),
    );
  }

  static Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('student_attempts');
    await prefs.remove('student_correct');
    await prefs.remove('student_scores');
    attempts = 0;
    correct = 0;
    scores.clear();
    loaded = true;
  }
}



class CurriculumPracticePage extends StatefulWidget {
  const CurriculumPracticePage({super.key});
  @override State<CurriculumPracticePage> createState() => _CurriculumPracticePageState();
}

class _CurriculumPracticePageState extends State<CurriculumPracticePage> {
  int classNo = 5;
  String subject = 'Mathematics';
  String chapter = 'Fractions';
  String difficulty = 'Easy';
  int index = 0, score = 0;
  bool answered = false;
  String selected = '';

  List<String> get chaptersForSubject {
    final data = {
      'Mathematics': ['Numbers','Fractions','Decimals','Percentage','Algebra','Geometry','Mensuration'],
      'Science': ['Living Things','Matter','Force & Motion','Light','Electricity','Environment'],
      'Hindi': ['शब्दार्थ','पर्यायवाची','विलोम','संज्ञा','सर्वनाम','व्याकरण'],
      'English': ['Vocabulary','Nouns','Pronouns','Adjectives','Tenses','Sentence Correction'],
      'Social Science': ['History','Geography','Civics','Economics'],
      'Computer': ['Hardware','Software','Internet','Programming Basics','Digital Safety'],
    };
    return data[subject]!;
  }

  List<Map<String, dynamic>> get questions {
    final key = '$subject|$chapter|$difficulty';
    final bank = <String, List<Map<String, dynamic>>>{
      'Mathematics|Fractions|Easy': [
        {'q':'1/2 + 1/2 = ?', 'o':['1/2','1','2','0'],'a':'1'},
        {'q':'Which fraction is equal to 1/2?', 'o':['1/3','2/4','3/5','4/5'],'a':'2/4'},
      ],
      'Mathematics|Percentage|Easy': [
        {'q':'10% of 200 = ?', 'o':['10','20','30','40'],'a':'20'},
        {'q':'50% means?', 'o':['1/4','1/2','1/5','2/5'],'a':'1/2'},
      ],
      'Science|Living Things|Easy': [
        {'q':'Plants make food mainly by?', 'o':['Photosynthesis','Digestion','Friction','Condensation'],'a':'Photosynthesis'},
        {'q':'Which is a living thing?', 'o':['Stone','Chair','Tree','Book'],'a':'Tree'},
      ],
      'English|Nouns|Easy': [
        {'q':'Which word is a noun?', 'o':['Run','Beautiful','School','Quickly'],'a':'School'},
        {'q':'Which is a proper noun?', 'o':['city','river','Ravi','boy'],'a':'Ravi'},
      ],
      'Hindi|विलोम|Easy': [
        {'q':'“दिन” का विलोम?', 'o':['सुबह','रात','दोपहर','सूरज'],'a':'रात'},
        {'q':'“सुख” का विलोम?', 'o':['आनंद','दुःख','हँसी','शांति'],'a':'दुःख'},
      ],
      'Social Science|Geography|Easy': [
        {'q':'Equator divides Earth approximately into?', 'o':['East/West','North/South','Land/Water','Hot/Cold'],'a':'North/South'},
        {'q':'Which is a natural resource?', 'o':['Plastic','Water','Computer','Car'],'a':'Water'},
      ],
      'Computer|Digital Safety|Easy': [
        {'q':'Should you share your OTP with a stranger?', 'o':['Yes','No'],'a':'No'},
        {'q':'Which is safer?', 'o':['Unique strong password','Same password everywhere'],'a':'Unique strong password'},
      ],
    };
    return bank[key] ?? [
      {'q':'इस chapter के प्रश्न जल्द ही और जोड़े जाएँगे।', 'o':['ठीक है','Skip'],'a':'ठीक है'}
    ];
  }

  void choose(String value) {
    if (answered) return;
    final ok = value == questions[index]['a'];
    StudentStore.record('curr_${classNo}_$subject_$chapter_$difficulty_$index', ok);
    setState(() { selected = value; answered = true; if (ok) score++; });
  }

  void reset() => setState(() { index = 0; score = 0; answered = false; selected = ''; });

  void next() {
    if (!answered) return;
    if (index == questions.length - 1) {
      showDialog(context: context, builder: (_) => AlertDialog(
        title: const Text('🎉 Chapter Practice Complete'),
        content: Text('Score: $score / ${questions.length}'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ));
      return;
    }
    setState(() { index++; answered = false; selected = ''; });
  }

  @override
  Widget build(BuildContext context) {
    final q = questions[index];
    final options = List<String>.from(q['o'] as List);
    return Scaffold(
      appBar: AppBar(title: const Text('Curriculum Practice')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Row(children: [
          Expanded(child: DropdownButtonFormField<int>(
            value: classNo,
            decoration: const InputDecoration(labelText: 'Class', border: OutlineInputBorder()),
            items: List.generate(10, (i) => DropdownMenuItem(value: i+1, child: Text('Class ${i+1}'))),
            onChanged: (v) => setState(() { classNo = v!; reset(); }),
          )),
          const SizedBox(width: 10),
          Expanded(child: DropdownButtonFormField<String>(
            value: subject,
            decoration: const InputDecoration(labelText: 'Subject', border: OutlineInputBorder()),
            items: ['Mathematics','Science','Hindi','English','Social Science','Computer']
              .map((x) => DropdownMenuItem(value: x, child: Text(x, overflow: TextOverflow.ellipsis))).toList(),
            onChanged: (v) => setState(() { subject = v!; chapter = chaptersForSubject.first; reset(); }),
          )),
        ]),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: chapter,
          decoration: const InputDecoration(labelText: 'Chapter', border: OutlineInputBorder()),
          items: chaptersForSubject.map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
          onChanged: (v) => setState(() { chapter = v!; reset(); }),
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: difficulty,
          decoration: const InputDecoration(labelText: 'Difficulty', border: OutlineInputBorder()),
          items: ['Easy','Medium','Hard'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
          onChanged: (v) => setState(() { difficulty = v!; reset(); }),
        ),
        const SizedBox(height: 18),
        LinearProgressIndicator(value: (index + 1) / questions.length),
        const SizedBox(height: 18),
        Text('Question ${index + 1}/${questions.length}',
          style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(q['q'] as String,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        ...options.map((o) => Padding(
          padding: const EdgeInsets.only(bottom: 9),
          child: OutlinedButton(
            onPressed: () => choose(o),
            child: Align(alignment: Alignment.centerLeft,
              child: Padding(padding: const EdgeInsets.all(10), child: Text(o))),
          ),
        )),
        if (answered) Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Text(
            selected == q['a'] ? '✅ सही उत्तर!' : '❌ सही उत्तर: ${q['a']}',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
        )),
        const SizedBox(height: 10),
        FilledButton(onPressed: answered ? next : null,
          child: Text(index == questions.length - 1 ? 'Finish' : 'Next')),
      ]),
    );
  }
}

class QuestionBankPage extends StatefulWidget {
  const QuestionBankPage({super.key});
  @override State<QuestionBankPage> createState() => _QuestionBankPageState();
}

class _QuestionBankPageState extends State<QuestionBankPage> {
  int classNo = 5;
  String subject = 'Mathematics';
  String difficulty = 'Easy';
  int index = 0;
  int score = 0;
  bool answered = false;
  String selected = '';

  List<Map<String, dynamic>> get questions {
    if (subject == 'Mathematics') {
      if (difficulty == 'Easy') return [
        {'q':'25 + 37 = ?', 'o':['52','62','72','42'],'a':'62'},
        {'q':'3 × 8 = ?', 'o':['11','21','24','28'],'a':'24'},
        {'q':'50% of 100 = ?', 'o':['25','50','75','100'],'a':'50'},
      ];
      if (difficulty == 'Medium') return [
        {'q':'3/4 + 1/4 = ?', 'o':['1/2','1','3/4','2'],'a':'1'},
        {'q':'2x + 4 = 14. x = ?', 'o':['4','5','6','7'],'a':'5'},
        {'q':'A rectangle is 8 cm × 5 cm. Area?', 'o':['13','26','40','80'],'a':'40'},
      ];
      return [
        {'q':'If CP = ₹500 and SP = ₹600, profit %?', 'o':['10%','15%','20%','25%'],'a':'20%'},
        {'q':'SI on ₹1000 at 5% for 2 years?', 'o':['₹50','₹100','₹150','₹200'],'a':'₹100'},
        {'q':'Speed 60 km/h for 2 hours. Distance?', 'o':['30 km','60 km','120 km','180 km'],'a':'120 km'},
      ];
    }
    if (subject == 'Science') return [
      {'q':'Plants make food by?', 'o':['Respiration','Photosynthesis','Digestion','Evaporation'],'a':'Photosynthesis'},
      {'q':'Which force pulls objects toward Earth?', 'o':['Friction','Gravity','Magnetism','Buoyancy'],'a':'Gravity'},
    ];
    if (subject == 'English') return [
      {'q':'Which is a noun?', 'o':['Run','Beautiful','School','Quickly'],'a':'School'},
      {'q':'Opposite of “hot”?', 'o':['Warm','Cold','Fast','Bright'],'a':'Cold'},
    ];
    if (subject == 'Hindi') return [
      {'q':'“दिन” का विलोम क्या है?', 'o':['सुबह','रात','सूर्य','समय'],'a':'रात'},
      {'q':'“जल” का पर्यायवाची?', 'o':['अग्नि','नीर','वायु','धरती'],'a':'नीर'},
    ];
    if (subject == 'Social Science') return [
      {'q':'भारत को स्वतंत्रता कब मिली?', 'o':['1945','1947','1950','1952'],'a':'1947'},
      {'q':'Equator किसे लगभग दो भागों में बाँटता है?', 'o':['चाँद','पृथ्वी','सूर्य','भारत'],'a':'पृथ्वी'},
    ];
    return [
      {'q':'CPU stands for?', 'o':['Central Processing Unit','Computer Power Unit','Central Program Utility'],'a':'Central Processing Unit'},
      {'q':'Which is an input device?', 'o':['Monitor','Printer','Keyboard','Speaker'],'a':'Keyboard'},
    ];
  }

  void choose(String value) {
    if (answered) return;
    final ok = value == questions[index]['a'];
    StudentStore.record('bank_${classNo}_${subject}_${difficulty}_$index', ok);
    setState(() { selected = value; answered = true; if (ok) score++; });
  }

  void next() {
    if (!answered) return;
    if (index >= questions.length - 1) {
      showDialog(context: context, builder: (_) => AlertDialog(
        title: const Text('🎉 Practice Complete'),
        content: Text('Score: $score / ${questions.length}'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ));
      return;
    }
    setState(() { index++; answered = false; selected = ''; });
  }

  void reset() => setState(() { index = 0; score = 0; answered = false; selected = ''; });

  @override
  Widget build(BuildContext context) {
    final q = questions[index];
    final options = List<String>.from(q['o'] as List);
    return Scaffold(
      appBar: AppBar(title: const Text('Question Bank')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Row(children: [
          Expanded(child: DropdownButtonFormField<int>(
            value: classNo, decoration: const InputDecoration(labelText: 'Class', border: OutlineInputBorder()),
            items: List.generate(10, (i) => DropdownMenuItem(value: i+1, child: Text('Class ${i+1}'))),
            onChanged: (v) => setState(() { classNo = v!; reset(); }),
          )),
          const SizedBox(width: 10),
          Expanded(child: DropdownButtonFormField<String>(
            value: subject, decoration: const InputDecoration(labelText: 'Subject', border: OutlineInputBorder()),
            items: ['Mathematics','Science','Hindi','English','Social Science','Computer']
              .map((x) => DropdownMenuItem(value: x, child: Text(x, overflow: TextOverflow.ellipsis))).toList(),
            onChanged: (v) => setState(() { subject = v!; reset(); }),
          )),
        ]),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: difficulty, decoration: const InputDecoration(labelText: 'Difficulty', border: OutlineInputBorder()),
          items: ['Easy','Medium','Hard'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
          onChanged: (v) => setState(() { difficulty = v!; reset(); }),
        ),
        const SizedBox(height: 18),
        LinearProgressIndicator(value: (index + 1) / questions.length),
        const SizedBox(height: 18),
        Text('Question ${index + 1}/${questions.length}',
          style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(q['q'] as String, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        ...options.map((o) => Padding(
          padding: const EdgeInsets.only(bottom: 9),
          child: OutlinedButton(
            onPressed: () => choose(o),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.all(13),
              side: BorderSide(
                color: answered && o == q['a'] ? Colors.green :
                       answered && o == selected ? Colors.red : Colors.grey,
              ),
            ),
            child: Align(alignment: Alignment.centerLeft, child: Text(o)),
          ),
        )),
        if (answered) Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Text(
            selected == q['a']
              ? '✅ सही! बहुत बढ़िया।'
              : '❌ सही उत्तर: ${q['a']}',
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
        )),
        const SizedBox(height: 10),
        FilledButton(onPressed: answered ? next : null,
          child: Text(index == questions.length - 1 ? 'Finish' : 'Next')),
      ]),
    );
  }
}


class RevisionPage extends StatefulWidget {
  const RevisionPage({super.key});
  @override State<RevisionPage> createState() => _RevisionPageState();
}

class _RevisionPageState extends State<RevisionPage> {
  int index = 0;
  int score = 0;
  bool answered = false;
  String selected = '';

  final qs = const [
    {'subject':'Mathematics','chapter':'Fractions','q':'1/2 + 1/4 = ?', 'o':['1/4','2/4','3/4','1'],'a':'3/4'},
    {'subject':'Science','chapter':'Living Things','q':'Plants make food by?', 'o':['Respiration','Photosynthesis','Digestion','Friction'],'a':'Photosynthesis'},
    {'subject':'Hindi','chapter':'विलोम','q':'“दिन” का विलोम?', 'o':['सुबह','रात','दोपहर','सूरज'],'a':'रात'},
    {'subject':'English','chapter':'Nouns','q':'Which is a noun?', 'o':['Run','School','Quickly','Beautiful'],'a':'School'},
    {'subject':'Social Science','chapter':'Geography','q':'Equator divides Earth approximately into?', 'o':['East/West','North/South','Hot/Cold','Land/Water'],'a':'North/South'},
    {'subject':'Computer','chapter':'Digital Safety','q':'Should you share an OTP with a stranger?', 'o':['Yes','No'],'a':'No'},
  ];

  void choose(String value) {
    if (answered) return;
    final ok = value == qs[index]['a'];
    StudentStore.record('revision_${qs[index]['subject']}_${qs[index]['chapter']}_$index', ok);
    setState(() { selected = value; answered = true; if (ok) score++; });
  }

  void next() {
    if (!answered) return;
    if (index == qs.length - 1) {
      showDialog(context: context, builder: (_) => AlertDialog(
        title: const Text('📋 Revision Complete'),
        content: Text('Score: $score / ${qs.length}\nAccuracy: ${score * 100 ~/ qs.length}%'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done'))],
      ));
      return;
    }
    setState(() { index++; answered = false; selected = ''; });
  }

  @override
  Widget build(BuildContext context) {
    final q = qs[index];
    final options = List<String>.from(q['o'] as List);
    return Scaffold(
      appBar: AppBar(title: const Text('Revision Test')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        LinearProgressIndicator(value: (index + 1) / qs.length),
        const SizedBox(height: 14),
        Text('${q['subject']} • ${q['chapter']}',
          style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Text('Question ${index + 1}/${qs.length}',
          style: const TextStyle(color: Colors.grey)),
        const SizedBox(height: 8),
        Text(q['q'] as String,
          style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        ...options.map((o) => Padding(
          padding: const EdgeInsets.only(bottom: 9),
          child: OutlinedButton(
            onPressed: () => choose(o),
            child: Align(alignment: Alignment.centerLeft,
              child: Padding(padding: const EdgeInsets.all(10), child: Text(o))),
          ),
        )),
        if (answered) Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Text(selected == q['a']
            ? '✅ सही!'
            : '❌ सही उत्तर: ${q['a']}',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        )),
        const SizedBox(height: 10),
        FilledButton(onPressed: answered ? next : null,
          child: Text(index == qs.length - 1 ? 'Finish' : 'Next')),
      ]),
    );
  }
}

class ProgressDetailsPage extends StatelessWidget {
  const ProgressDetailsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final attempts = StudentStore.attempts;
    final correct = StudentStore.correct;
    final accuracy = attempts == 0 ? 0 : correct * 100 ~/ attempts;
    return Scaffold(
      appBar: AppBar(title: const Text('Progress Details')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Card(child: ListTile(
          leading: const Icon(Icons.quiz),
          title: const Text('Total Attempts'),
          trailing: Text('$attempts', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        )),
        Card(child: ListTile(
          leading: const Icon(Icons.check_circle),
          title: const Text('Correct'),
          trailing: Text('$correct', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        )),
        Card(child: ListTile(
          leading: const Icon(Icons.percent),
          title: const Text('Overall Accuracy'),
          trailing: Text('$accuracy%', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        )),
        const SizedBox(height: 12),
        const Card(child: Padding(
          padding: EdgeInsets.all(16),
          child: Text(
            '🎯 Weak chapters will be identified more accurately after the app stores '
            'per-chapter history persistently. Progress is saved locally on this device; no account is required.'
          ),
        )),
      ]),
    );
  }
}



class BetaChecklistPage extends StatelessWidget {
  const BetaChecklistPage({super.key});

  @override
  Widget build(BuildContext context) {
    final checks = const [
      ['📷', 'Camera/OCR', 'Photo लेकर OCR result को check/edit करें।'],
      ['🧮', 'Maths', 'Basic arithmetic, fractions और equations के sample questions चलाएँ।'],
      ['🔬', 'Science', 'Common concepts के explanations verify करें।'],
      ['📚', 'Other subjects', 'Hindi, English, Social Science और Computer के sample questions चलाएँ।'],
      ['🎙️', 'Voice', 'Voice input और Hindi teacher voice को device पर test करें।'],
      ['📊', 'Progress', 'Quiz करें, app बंद करके दोबारा खोलें और progress बना रहने की जाँच करें।'],
      ['🔐', 'Privacy', 'Privacy page देखें और Delete My Learning Progress को test करें।'],
      ['📱', 'UI', 'छोटे screen पर buttons, text और dropdowns सही दिख रहे हैं या नहीं देखें।'],
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Beta Test Checklist')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Card(child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'यह build beta testing के लिए checklist देता है। '
              'अभी वास्तविक device पर manual testing जरूरी है।',
              style: TextStyle(fontSize: 16),
            ),
          )),
          const SizedBox(height: 10),
          ...checks.map((c) => Card(
            child: ListTile(
              leading: Text(c[0], style: const TextStyle(fontSize: 24)),
              title: Text(c[1], style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(c[2]),
            ),
          )),
          const SizedBox(height: 8),
          const Card(child: ListTile(
            leading: Icon(Icons.warning_amber),
            title: Text('Important'),
            subtitle: Text(
              'Production release से पहले Android permissions, network traffic, '
              'OCR/photo lifecycle और child-safety/privacy requirements की independent review करें.'
            ),
          )),
        ],
      ),
    );
  }
}

class PrivacySecurityPage extends StatelessWidget {
  const PrivacySecurityPage({super.key});

  Future<void> _deleteProgress(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete progress?'),
        content: const Text(
          'यह इस device पर saved attempts, correct answers और practice progress मिटा देगा। '
          'यह action वापस नहीं किया जा सकता।'
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok == true) {
      await StudentStore.clearAll();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Local progress deleted.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy & Security')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Card(child: ListTile(
            leading: Icon(Icons.phone_android),
            title: Text('Local-first'),
            subtitle: Text('Basic learning progress is stored on this device.'),
          )),
          const Card(child: ListTile(
            leading: Icon(Icons.cloud_off),
            title: Text('No cloud progress database'),
            subtitle: Text('The prototype does not need an online account to save progress.'),
          )),
          const Card(child: ListTile(
            leading: Icon(Icons.photo_camera_back),
            title: Text('Photo/OCR privacy'),
            subtitle: Text('The app flow is designed so photos are processed locally rather than uploaded by this prototype.'),
          )),
          const Card(child: ListTile(
            leading: Icon(Icons.security),
            title: Text('Data minimization'),
            subtitle: Text('Do not enter passwords, OTPs, banking details or other sensitive secrets into the learning app.'),
          )),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => _deleteProgress(context),
            icon: const Icon(Icons.delete_forever),
            label: const Text('Delete My Learning Progress'),
          ),
        ],
      ),
    );
  }
}

class StudentModePage extends StatelessWidget {
  const StudentModePage({super.key});

  @override
  Widget build(BuildContext context) {
    final accuracy = StudentStore.attempts == 0
        ? 0
        : (StudentStore.correct * 100 ~/ StudentStore.attempts);
    return Scaffold(
      appBar: AppBar(title: const Text('My Learning')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('📊 Progress',
                style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Text('Questions attempted: ${StudentStore.attempts}'),
              Text('Correct: ${StudentStore.correct}'),
              Text('Accuracy: $accuracy%'),
            ]),
          )),
          const SizedBox(height: 12),
          Card(child: ListTile(
            leading: const Icon(Icons.quiz),
            title: const Text('Practice Quiz'),
            subtitle: const Text('Offline sample quiz — no account required'),
            onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const QuizPage())),
          )),
          const SizedBox(height: 10),
          Card(child: ListTile(
            leading: const Icon(Icons.library_books),
            title: const Text('Question Bank'),
            subtitle: const Text('Class 1–10 • Subject • Easy / Medium / Hard'),
            onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const QuestionBankPage())),
          )),
          const SizedBox(height: 10),
          Card(child: ListTile(
            leading: const Icon(Icons.fact_check),
            title: const Text('Revision Test'),
            subtitle: const Text('Mixed questions from all subjects'),
            onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const RevisionPage())),
          )),
          const SizedBox(height: 10),
          Card(child: ListTile(
            leading: const Icon(Icons.bar_chart),
            title: const Text('Progress Details'),
            subtitle: const Text('Attempts, correct answers and accuracy'),
            onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const ProgressDetailsPage())),
          )),
          const SizedBox(height: 10),
          Card(child: ListTile(
            leading: const Icon(Icons.privacy_tip),
            title: const Text('Privacy & Security'),
            subtitle: const Text('Local data, privacy information and delete option'),
            onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const PrivacySecurityPage())),
          )),
          const SizedBox(height: 10),
          Card(child: ListTile(
            leading: const Icon(Icons.fact_check_outlined),
            title: const Text('Beta Test Checklist'),
            subtitle: const Text('Device पर release से पहले क्या-क्या test करना है'),
            onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const BetaChecklistPage())),
          )),
          const SizedBox(height: 10),
          Card(child: ListTile(
            leading: const Icon(Icons.menu_book),
            title: const Text('Chapter Practice'),
            subtitle: const Text('Class → Subject → Chapter → Difficulty'),
            onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const CurriculumPracticePage())),
          )),
          const Card(child: ListTile(
            leading: Icon(Icons.lock_outline),
            title: Text('Privacy-first progress'),
            subtitle: Text('This prototype keeps progress only in app memory.'),
          )),
        ],
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});
  @override State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  final questions = const [
    {'q': '25% of 200 = ?', 'options': ['25', '50', '75', '100'], 'answer': '50'},
    {'q': '2 + 8 × 2 = ?', 'options': ['20', '18', '16', '12'], 'answer': '18'},
    {'q': 'A noun names a person, place, thing or idea.', 'options': ['True', 'False'], 'answer': 'True'},
    {'q': 'Which is a renewable energy source?', 'options': ['Coal', 'Petrol', 'Solar', 'Diesel'], 'answer': 'Solar'},
    {'q': 'CPU stands for?', 'options': ['Central Processing Unit', 'Computer Power Unit', 'Central Program Utility'], 'answer': 'Central Processing Unit'},
  ];
  int index = 0;
  int score = 0;
  bool answered = false;

  void choose(String value) {
    if (answered) return;
    final ok = value == questions[index]['answer'];
    StudentStore.record('quiz_$index', ok);
    setState(() {
      answered = true;
      if (ok) score++;
    });
  }

  void next() {
    if (!answered) return;
    if (index == questions.length - 1) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('🎉 Quiz Complete'),
          content: Text('Score: $score / ${questions.length}'),
          actions: [TextButton(onPressed: () => Navigator.popUntil(context, (r) => r.isFirst),
            child: const Text('Done'))],
        ),
      );
      return;
    }
    setState(() {
      index++;
      answered = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final q = questions[index];
    final opts = (q['options'] as List<String>);
    return Scaffold(
      appBar: AppBar(title: Text('Practice ${index + 1}/${questions.length}')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          LinearProgressIndicator(value: (index + 1) / questions.length),
          const SizedBox(height: 24),
          Text(q['q'] as String,
            style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          ...opts.map((o) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: OutlinedButton(
              onPressed: () => choose(o),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(o, style: const TextStyle(fontSize: 17)),
              ),
            ),
          )),
          if (answered)
            Card(child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(
                'Answer checked. Correct answer: ${q['answer']}'
              ),
            )),
          const SizedBox(height: 10),
          FilledButton(
            onPressed: answered ? next : null,
            child: Text(index == questions.length - 1 ? 'Finish' : 'Next'),
          ),
        ],
      ),
    );
  }
}

class ClassPage extends StatelessWidget {
  const ClassPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('कक्षा चुनें')),
    body: GridView.builder(
      padding: const EdgeInsets.all(20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 1.35),
      itemCount: 10,
      itemBuilder: (_, i) {
        final c = i + 1;
        return Card(child: InkWell(
          onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => SubjectPage(classNo: c))),
          child: Center(child: Text('Class $c',
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)))));
      },
    ),
  );
}

class SubjectPage extends StatelessWidget {
  final int classNo;
  const SubjectPage({super.key, required this.classNo});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Class $classNo • Subject')),
    body: ListView.separated(
      padding: const EdgeInsets.all(20), itemCount: subjects.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) => Card(child: ListTile(
        leading: CircleAvatar(child: Icon(subjects[i] == 'Mathematics' ? Icons.calculate : Icons.menu_book)),
        title: Text(subjects[i]), trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(
          builder: (_) => ChapterPage(classNo: classNo, subject: subjects[i]))))),
    ),
  );
}

class ChapterPage extends StatelessWidget {
  final int classNo; final String subject;
  const ChapterPage({super.key, required this.classNo, required this.subject});
  @override
  Widget build(BuildContext context) {
    final list = subject == 'Mathematics'
        ? chapters(classNo)
        : ['Concepts','Examples','Practice','Ask Teacher'];
    return Scaffold(
      appBar: AppBar(title: Text('$subject • Class $classNo')),
      body: ListView.separated(
        padding: const EdgeInsets.all(20), itemCount: list.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (_, i) => Card(child: ListTile(
          leading: CircleAvatar(child: Text('${i + 1}')), title: Text(list[i]),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => AskPage(classNo: classNo, subject: subject, chapter: list[i]))))),
      ),
    );
  }
}


String? solveScience(String raw, int classNo, String chapter) {
  final q = raw.toLowerCase().trim();

  final answers = <String, String>{
    'photosynthesis':
      'प्रकाश संश्लेषण वह प्रक्रिया है जिसमें हरे पौधे सूर्य के प्रकाश की सहायता से पानी और कार्बन डाइऑक्साइड से अपना भोजन बनाते हैं।\\n\\nमुख्य आवश्यकताएँ: सूर्य का प्रकाश, क्लोरोफिल, पानी और कार्बन डाइऑक्साइड।',
    'प्रकाश संश्लेषण':
      'प्रकाश संश्लेषण वह प्रक्रिया है जिसमें हरे पौधे सूर्य के प्रकाश की सहायता से पानी और कार्बन डाइऑक्साइड से अपना भोजन बनाते हैं।\\n\\nमुख्य आवश्यकताएँ: सूर्य का प्रकाश, क्लोरोफिल, पानी और कार्बन डाइऑक्साइड।',
    'gravity':
      'गुरुत्वाकर्षण वह बल है जो वस्तुओं को पृथ्वी की ओर खींचता है। इसी कारण वस्तुएँ नीचे गिरती हैं और हम पृथ्वी पर टिके रहते हैं।',
    'गुरुत्वाकर्षण':
      'गुरुत्वाकर्षण वह बल है जो वस्तुओं को पृथ्वी की ओर खींचता है। इसी कारण वस्तुएँ नीचे गिरती हैं और हम पृथ्वी पर टिके रहते हैं।',
    'water cycle':
      'जल चक्र में वाष्पीकरण, संघनन और वर्षण जैसी प्रक्रियाएँ शामिल होती हैं। पानी लगातार वातावरण और पृथ्वी के बीच घूमता रहता है।',
    'जल चक्र':
      'जल चक्र में वाष्पीकरण, संघनन और वर्षण जैसी प्रक्रियाएँ शामिल होती हैं। पानी लगातार वातावरण और पृथ्वी के बीच घूमता रहता है।',
    'food chain':
      'खाद्य श्रृंखला में ऊर्जा एक जीव से दूसरे जीव तक भोजन के माध्यम से पहुँचती है। उदाहरण: घास → हिरण → शेर।',
    'खाद्य श्रृंखला':
      'खाद्य श्रृंखला में ऊर्जा एक जीव से दूसरे जीव तक भोजन के माध्यम से पहुँचती है। उदाहरण: घास → हिरण → शेर।',
    'photosynthesis equation':
      'सरल रूप में: कार्बन डाइऑक्साइड + पानी → ग्लूकोज़ + ऑक्सीजन। यह प्रक्रिया प्रकाश और क्लोरोफिल की उपस्थिति में होती है।',
  };

  for (final entry in answers.entries) {
    if (q.contains(entry.key)) {
      return '👨‍🏫 Teacher Explanation\\n\\n${entry.value}\\n\\n'
          'कक्षा: $classNo\\nChapter: $chapter\\n\\n'
          '💡 याद रखने की trick: concept को एक छोटे उदाहरण से जोड़कर याद करें।';
    }
  }

  if (q.contains('solid') || q.contains('ठोस')) {
    return 'ठोस पदार्थ का निश्चित आकार और निश्चित आयतन होता है। इसके कण सामान्यतः एक-दूसरे के काफी पास होते हैं।';
  }
  if (q.contains('liquid') || q.contains('द्रव')) {
    return 'द्रव का निश्चित आयतन होता है, लेकिन अपना निश्चित आकार नहीं होता। यह जिस पात्र में रखा जाए उसका आकार ले लेता है।';
  }
  if (q.contains('gas') || q.contains('गैस')) {
    return 'गैस का न निश्चित आकार होता है और न निश्चित आयतन। यह उपलब्ध स्थान में फैल जाती है।';
  }
  if (q.contains('force') || q.contains('बल')) {
    return 'बल किसी वस्तु की गति, दिशा या आकार में परिवर्तन कर सकता है। उदाहरण: गेंद को धक्का देने पर उसकी गति बदलती है।';
  }
  if (q.contains('friction') || q.contains('घर्षण')) {
    return 'घर्षण वह बल है जो संपर्क में आई सतहों की सापेक्ष गति का विरोध करता है। चलना, ब्रेक लगाना और वस्तुओं को पकड़ना घर्षण के उदाहरण हैं।';
  }
  if (q.contains('evaporation') || q.contains('वाष्पीकरण')) {
    return 'वाष्पीकरण में द्रव की सतह से कण गैस की अवस्था में चले जाते हैं। गर्मी बढ़ने पर यह प्रक्रिया सामान्यतः तेज होती है।';
  }
  if (q.contains('condensation') || q.contains('संघनन')) {
    return 'संघनन में गैस या जलवाष्प ठंडी होकर द्रव में बदलती है। ठंडी सतह पर पानी की बूंदें इसका उदाहरण हैं।';
  }
  if (q.contains('photosynthesis') || q.contains('प्रकाश संश्लेषण')) {
    return 'प्रकाश संश्लेषण में हरे पौधे सूर्य के प्रकाश की सहायता से कार्बन डाइऑक्साइड और पानी से भोजन बनाते हैं और ऑक्सीजन छोड़ते हैं।';
  }
  if (q.contains('respiration') || q.contains('श्वसन')) {
    return 'श्वसन वह प्रक्रिया है जिसमें जीव भोजन से ऊर्जा प्राप्त करते हैं। मनुष्य में ऑक्सीजन की सहायता से भोजन से ऊर्जा निकलती है।';
  }
  if (q.contains('cell') || q.contains('कोशिका')) {
    return 'कोशिका जीवों की मूल संरचनात्मक और क्रियात्मक इकाई है। पौधों और जन्तुओं के शरीर अनेक कोशिकाओं से बने होते हैं।';
  }
  if (q.contains('ecosystem') || q.contains('पारिस्थितिकी')) {
    return 'पारिस्थितिकी तंत्र में जीवित घटक और उनके आसपास के निर्जीव घटक मिलकर एक तंत्र बनाते हैं।';
  }
  if (q.contains('solar system') || q.contains('सौर मंडल')) {
    return 'सौर मंडल में सूर्य और उसके चारों ओर परिक्रमा करने वाले ग्रह, उनके उपग्रह तथा अन्य खगोलीय पिंड शामिल हैं।';
  }
  if (q.contains('planet') || q.contains('ग्रह')) {
    return 'ग्रह ऐसे खगोलीय पिंड हैं जो किसी तारे की परिक्रमा करते हैं। पृथ्वी सूर्य की परिक्रमा करने वाला एक ग्रह है।';
  }
  if (q.contains('magnet') || q.contains('चुंबक')) {
    return 'चुंबक कुछ पदार्थों, विशेषकर लोहे जैसी वस्तुओं को आकर्षित कर सकता है। चुंबक के दो ध्रुव होते हैं—उत्तर और दक्षिण।';
  }
  if (q.contains('electric circuit') || q.contains('विद्युत परिपथ')) {
    return 'विद्युत परिपथ विद्युत धारा के प्रवाह का बंद मार्ग है। सरल परिपथ में सेल, तार और बल्ब जैसे घटक हो सकते हैं।';
  }
  if (q.contains('acid') || q.contains('अम्ल')) {
    return 'अम्ल ऐसे पदार्थ हैं जिनमें अम्लीय गुण होते हैं। नींबू के रस में पाया जाने वाला साइट्रिक अम्ल इसका सामान्य उदाहरण है।';
  }
  if (q.contains('base') || q.contains('क्षार')) {
    return 'क्षार ऐसे पदार्थ हैं जिनमें क्षारीय गुण होते हैं। साबुन के कुछ घोल क्षारीय प्रकृति के हो सकते हैं।';
  }
  if (q.contains('human heart') || q.contains('हृदय')) {
    return 'हृदय एक पेशीय अंग है जो रक्त को पूरे शरीर में पंप करता है।';
  }
  if (q.contains('digest') || q.contains('पाचन')) {
    return 'पाचन में भोजन के जटिल पदार्थ टूटकर सरल पदार्थों में बदलते हैं, जिन्हें शरीर अवशोषित कर सकता है।';
  }
  if (q.contains('renewable') || q.contains('नवीकरणीय')) {
    return 'नवीकरणीय ऊर्जा ऐसे स्रोतों से मिलती है जो प्राकृतिक रूप से फिर उपलब्ध होते रहते हैं, जैसे सूर्य, हवा और बहता पानी।';
  }
  if (q.contains('non renewable') || q.contains('अनवीकरणीय')) {
    return 'अनवीकरणीय संसाधन सीमित होते हैं और बनने में बहुत लंबा समय लग सकता है, जैसे कोयला और पेट्रोलियम।';
  }
  return null;
}


String? solveHindi(String raw, int classNo, String chapter) {
  final q = raw.toLowerCase().trim();

  if (q.contains('पर्यायवाची') || q.contains('synonym')) {
    final words = {
      'सूर्य': 'रवि, भानु, दिनकर',
      'जल': 'पानी, नीर, वारि',
      'आकाश': 'नभ, गगन, अम्बर',
      'पृथ्वी': 'धरती, धरा, भूमि',
      'सूरज': 'सूर्य, रवि, भानु',
    };
    for (final e in words.entries) {
      if (q.contains(e.key)) {
        return '👨‍🏫 Teacher Explanation\n\n'
          '“${e.key}” के पर्यायवाची: ${e.value}\n\n'
          '💡 Trick: पर्यायवाची शब्दों का अर्थ समान या बहुत मिलता-जुलता होता है।';
      }
    }
    return 'पर्यायवाची का मतलब है—ऐसे शब्द जिनके अर्थ समान या मिलते-जुलते हों। उदाहरण: जल–पानी।';
  }

  if (q.contains('विलोम') || q.contains('antonym')) {
    final words = {
      'दिन': 'रात', 'अच्छा': 'बुरा', 'बड़ा': 'छोटा', 'सुख': 'दुःख',
      'सत्य': 'असत्य', 'आना': 'जाना', 'ऊँचा': 'नीचा', 'नया': 'पुराना',
    };
    for (final e in words.entries) {
      if (q.contains(e.key)) {
        return '👨‍🏫 Teacher Explanation\n\n'
          '“${e.key}” का विलोम: ${e.value}\n\n'
          '💡 Trick: विलोम शब्द अर्थ में विपरीत होते हैं।';
      }
    }
    return 'विलोम शब्द वे होते हैं जिनके अर्थ एक-दूसरे के विपरीत होते हैं। उदाहरण: दिन–रात।';
  }

  if (q.contains('संज्ञा')) {
    return 'संज्ञा वह शब्द है जिससे किसी व्यक्ति, वस्तु, स्थान, प्राणी या भाव का बोध होता है।\n\n'
      'उदाहरण: राम, दिल्ली, पुस्तक, गाय, ईमानदारी।\n\n'
      '💡 Trick: “किसका नाम?” पूछकर संज्ञा पहचानने की कोशिश करें।';
  }

  if (q.contains('सर्वनाम')) {
    return 'सर्वनाम वह शब्द है जो संज्ञा के स्थान पर प्रयोग होता है।\n\n'
      'उदाहरण: मैं, हम, तुम, वह, यह, वे।\n\n'
      '💡 Trick: नाम को बार-बार बोलने के बजाय उसके स्थान पर आने वाला शब्द अक्सर सर्वनाम होता है।';
  }

  if (q.contains('विशेषण')) {
    return 'विशेषण वह शब्द है जो संज्ञा या सर्वनाम की विशेषता बताता है।\n\n'
      'उदाहरण: सुंदर फूल, लाल गेंद, पाँच बच्चे।\n\n'
      'Teacher: “कैसा, कितने, कौन-सा?” जैसे प्रश्न विशेषण पहचानने में मदद कर सकते हैं।';
  }

  if (q.contains('क्रिया')) {
    return 'क्रिया वह शब्द है जिससे किसी काम के करने या होने का बोध होता है।\n\n'
      'उदाहरण: खाना, पढ़ना, दौड़ना, सोना, लिखना।';
  }

  if (q.contains('लिंग')) {
    return 'हिंदी में मुख्य रूप से दो लिंग माने जाते हैं—पुल्लिंग और स्त्रीलिंग।\n\n'
      'उदाहरण: लड़का–लड़की, राजा–रानी।';
  }

  if (q.contains('वचन')) {
    return 'वचन से संख्या का बोध होता है। इसके दो मुख्य रूप हैं—एकवचन और बहुवचन।\n\n'
      'उदाहरण: बच्चा–बच्चे, पुस्तक–पुस्तकें।';
  }

  if (q.contains('मुहावरा')) {
    return 'मुहावरा ऐसा प्रचलित वाक्यांश है जिसका अर्थ उसके शब्दों के सीधे अर्थ से अलग हो सकता है।\n\n'
      'उदाहरण: “नाक कटना” = अपमान होना।';
  }

  if (q.contains('वाक्य') && (q.contains('सुधार') || q.contains('शुद्ध'))) {
    return 'वाक्य सुधारते समय वर्तनी, लिंग, वचन, काल और शब्दों के सही क्रम को देखें।\n\n'
      'Teacher Trick: पहले कर्ता पहचानें, फिर क्रिया और फिर देखें कि दोनों में लिंग-वचन का मेल है या नहीं।';
  }

  if (q.contains('शब्दार्थ') || q.contains('meaning')) {
    final words = {
      'आनंद': 'खुशी',
      'प्रसन्न': 'खुश',
      'साहस': 'हिम्मत',
      'वन': 'जंगल',
      'नदी': 'बहता हुआ जल-प्रवाह',
    };
    for (final e in words.entries) {
      if (q.contains(e.key)) {
        return '“${e.key}” का शब्दार्थ: ${e.value}\n\n'
          '💡 Teacher: शब्द का अर्थ याद करने के लिए उसे एक छोटे वाक्य में प्रयोग करें।';
      }
    }
    return 'शब्दार्थ का मतलब है किसी शब्द का अर्थ या meaning।';
  }

  return null;
}


String? solveEnglish(String raw, int classNo, String chapter) {
  final q = raw.toLowerCase().trim();

  if (q.contains('noun') || q.contains('संज्ञा')) {
    return '👨‍🏫 Teacher Explanation\n\n'
      'A noun is a word used to name a person, place, animal, thing, or idea.\n\n'
      'Examples: Rahul, school, dog, book, honesty.\n\n'
      '💡 Trick: Ask “Who?” or “What?” to help identify a noun.';
  }

  if (q.contains('pronoun') || q.contains('सर्वनाम')) {
    return 'A pronoun is a word used instead of a noun.\n\n'
      'Examples: I, you, he, she, it, we, they.\n\n'
      '💡 Trick: If a word replaces a person or thing already named, it may be a pronoun.';
  }

  if (q.contains('adjective') || q.contains('विशेषण')) {
    return 'An adjective describes a noun or pronoun.\n\n'
      'Examples: a red ball, a tall boy, three books.\n\n'
      'Teacher Trick: Ask “What kind?”, “Which one?” or “How many?”';
  }

  if (q.contains('verb') || q.contains('क्रिया')) {
    return 'A verb shows an action or a state of being.\n\n'
      'Examples: run, eat, write, sleep, is, are.\n\n'
      '💡 Trick: Find the action or what the subject is doing.';
  }

  if (q.contains('adverb')) {
    return 'An adverb commonly tells us how, when, or where an action happens.\n\n'
      'Example: She runs quickly. Here “quickly” tells us how she runs.';
  }

  if (q.contains('present tense') || q.contains('वर्तमान काल')) {
    return 'Present tense is commonly used for actions happening now or habits.\n\n'
      'Examples: I play. She reads. They go to school.\n\n'
      '💡 Trick: For simple present, remember subject-verb agreement: He/She/It often takes a verb ending in -s/-es.';
  }

  if (q.contains('past tense') || q.contains('भूतकाल')) {
    return 'Past tense is used for actions that happened before now.\n\n'
      'Examples: I played. She visited Delhi. They went home.';
  }

  if (q.contains('future tense') || q.contains('भविष्य')) {
    return 'Future tense is used for actions expected to happen later.\n\n'
      'Example: I will study tomorrow.';
  }

  if (q.contains('synonym')) {
    final map = {
      'happy': 'glad, joyful',
      'big': 'large, huge',
      'small': 'little, tiny',
      'fast': 'quick, rapid',
      'begin': 'start, commence',
    };
    for (final e in map.entries) {
      if (q.contains(e.key)) {
        return 'Synonyms of “${e.key}”: ${e.value}.\n\n'
          '💡 Synonyms have similar or nearly similar meanings.';
      }
    }
    return 'Synonyms are words with similar or nearly similar meanings.';
  }

  if (q.contains('antonym')) {
    final map = {
      'happy': 'sad',
      'big': 'small',
      'hot': 'cold',
      'early': 'late',
      'easy': 'difficult',
    };
    for (final e in map.entries) {
      if (q.contains(e.key)) {
        return 'Antonym of “${e.key}”: ${e.value}.\n\n'
          '💡 Antonyms have opposite meanings.';
      }
    }
    return 'Antonyms are words with opposite meanings.';
  }

  if (q.contains('article') || q.contains(' a ') || q.contains(' an ') || q.contains(' the ')) {
    return 'English articles are “a”, “an”, and “the”.\n\n'
      'Use “a” before a singular countable noun with a consonant sound: a book.\n'
      'Use “an” before a vowel sound: an apple.\n'
      'Use “the” when talking about a specific or already-known thing.';
  }

  if (q.contains('sentence') && (q.contains('correct') || q.contains('correction'))) {
    return 'For sentence correction, check subject-verb agreement, tense, articles, spelling, and word order.\n\n'
      'Teacher Trick: First find the subject and main verb, then check whether they agree.';
  }

  if (q.contains('meaning') || q.contains('vocabulary')) {
    final map = {
      'brave': 'having courage',
      'honest': 'truthful',
      'ancient': 'very old',
      'rapid': 'very fast',
      'assist': 'help',
    };
    for (final e in map.entries) {
      if (q.contains(e.key)) {
        return '“${e.key}” means: ${e.value}.\n\n'
          '💡 Try using the word in a short sentence to remember it.';
      }
    }
    return 'Vocabulary means the collection of words a person knows and uses.';
  }

  return null;
}


String? solveSocialScience(String raw, int classNo, String chapter) {
  final q = raw.toLowerCase().trim();

  final history = <String, String>{
    'indus': 'सिंधु घाटी सभ्यता भारतीय उपमहाद्वीप की प्राचीन नगरीय सभ्यताओं में से एक थी। हड़प्पा और मोहनजोदड़ो इसके प्रमुख स्थल हैं।',
    'सिंधु': 'सिंधु घाटी सभ्यता भारतीय उपमहाद्वीप की प्राचीन नगरीय सभ्यताओं में से एक थी। हड़प्पा और मोहनजोदड़ो इसके प्रमुख स्थल हैं।',
    'ashoka': 'सम्राट अशोक मौर्य वंश के प्रमुख शासक थे। कलिंग युद्ध के बाद उनके जीवन में महत्वपूर्ण परिवर्तन आया और उन्होंने बौद्ध धर्म तथा अहिंसा के विचारों को बढ़ावा दिया।',
    'अशोक': 'सम्राट अशोक मौर्य वंश के प्रमुख शासक थे। कलिंग युद्ध के बाद उनके जीवन में महत्वपूर्ण परिवर्तन आया और उन्होंने बौद्ध धर्म तथा अहिंसा के विचारों को बढ़ावा दिया।',
    '1857': '1857 का विद्रोह ब्रिटिश शासन के विरुद्ध एक बड़ा विद्रोह था। इसके कई राजनीतिक, आर्थिक, सामाजिक और सैन्य कारण थे।',
    'स्वतंत्रता': 'भारत को 15 अगस्त 1947 को ब्रिटिश शासन से स्वतंत्रता मिली।'
  };
  for (final e in history.entries) {
    if (q.contains(e.key)) return '🏛️ History\\n\\n${e.value}\\n\\n💡 Teacher Trick: घटना को कारण → घटना → परिणाम के क्रम में याद करें।';
  }

  final geography = <String, String>{
    'equator': 'भूमध्य रेखा पृथ्वी को लगभग दो बराबर भागों—उत्तरी गोलार्ध और दक्षिणी गोलार्ध—में बाँटती है।',
    'भूमध्य रेखा': 'भूमध्य रेखा पृथ्वी को लगभग दो बराबर भागों—उत्तरी गोलार्ध और दक्षिणी गोलार्ध—में बाँटती है।',
    'latitude': 'अक्षांश भूमध्य रेखा के उत्तर या दक्षिण किसी स्थान की कोणीय दूरी को दर्शाता है।',
    'अक्षांश': 'अक्षांश भूमध्य रेखा के उत्तर या दक्षिण किसी स्थान की कोणीय दूरी को दर्शाता है।',
    'longitude': 'देशांतर प्रधान मध्याह्न रेखा के पूर्व या पश्चिम किसी स्थान की कोणीय दूरी को दर्शाता है।',
    'देशांतर': 'देशांतर प्रधान मध्याह्न रेखा के पूर्व या पश्चिम किसी स्थान की कोणीय दूरी को दर्शाता है।',
    'monsoon': 'मानसून मौसमी पवनों का तंत्र है, जो भारत में वर्षा के वितरण में महत्वपूर्ण भूमिका निभाता है।',
    'मानसून': 'मानसून मौसमी पवनों का तंत्र है, जो भारत में वर्षा के वितरण में महत्वपूर्ण भूमिका निभाता है।'
  };
  for (final e in geography.entries) {
    if (q.contains(e.key)) return '🌍 Geography\\n\\n${e.value}\\n\\n💡 Teacher Trick: मानचित्र पर स्थान देखकर concept को याद करना आसान होता है।';
  }

  final civics = <String, String>{
    'democracy': 'लोकतंत्र शासन की ऐसी व्यवस्था है जिसमें जनता की भागीदारी और प्रतिनिधियों का चुनाव महत्वपूर्ण होता है।',
    'लोकतंत्र': 'लोकतंत्र शासन की ऐसी व्यवस्था है जिसमें जनता की भागीदारी और प्रतिनिधियों का चुनाव महत्वपूर्ण होता है।',
    'constitution': 'संविधान किसी देश के शासन की मूल व्यवस्था, संस्थाओं, अधिकारों और नियमों का आधार प्रदान करता है।',
    'संविधान': 'संविधान किसी देश के शासन की मूल व्यवस्था, संस्थाओं, अधिकारों और नियमों का आधार प्रदान करता है।',
    'fundamental rights': 'मौलिक अधिकार नागरिकों की स्वतंत्रता और गरिमा की रक्षा करने वाले संवैधानिक अधिकार हैं।',
    'मौलिक अधिकार': 'मौलिक अधिकार नागरिकों की स्वतंत्रता और गरिमा की रक्षा करने वाले संवैधानिक अधिकार हैं।'
  };
  for (final e in civics.entries) {
    if (q.contains(e.key)) return '⚖️ Civics\\n\\n${e.value}\\n\\n💡 Teacher Trick: अधिकारों के साथ नागरिक कर्तव्यों और जिम्मेदारियों को भी याद रखें।';
  }

  final economics = <String, String>{
    'demand': 'माँग किसी वस्तु या सेवा की वह मात्रा है जिसे उपभोक्ता किसी निश्चित कीमत पर खरीदना चाहते और सक्षम होते हैं।',
    'मांग': 'माँग किसी वस्तु या सेवा की वह मात्रा है जिसे उपभोक्ता किसी निश्चित कीमत पर खरीदना चाहते और सक्षम होते हैं।',
    'supply': 'आपूर्ति किसी वस्तु या सेवा की वह मात्रा है जिसे विक्रेता किसी निश्चित कीमत पर बाजार में उपलब्ध कराना चाहते हैं।',
    'आपूर्ति': 'आपूर्ति किसी वस्तु या सेवा की वह मात्रा है जिसे विक्रेता किसी निश्चित कीमत पर बाजार में उपलब्ध कराना चाहते हैं।',
    'inflation': 'मुद्रास्फीति सामान्य कीमत स्तर में लगातार वृद्धि की स्थिति है, जिससे समान धन से कम वस्तुएँ खरीदी जा सकती हैं।',
    'मुद्रास्फीति': 'मुद्रास्फीति सामान्य कीमत स्तर में लगातार वृद्धि की स्थिति है, जिससे समान धन से कम वस्तुएँ खरीदी जा सकती हैं।'
  };
  for (final e in economics.entries) {
    if (q.contains(e.key)) return '💰 Economics\\n\\n${e.value}\\n\\n💡 Teacher Trick: रोजमर्रा की खरीदारी और कीमतों के उदाहरण से economics concepts समझें।';
  }

  if (q.contains('history') || q.contains('इतिहास')) {
    return 'History में घटनाओं को समय, कारण, प्रमुख व्यक्ति और परिणाम के आधार पर पढ़ना आसान होता है।';
  }
  if (q.contains('geography') || q.contains('भूगोल')) {
    return 'Geography में maps, location, climate, resources और people-environment relationship को समझना महत्वपूर्ण है।';
  }
  if (q.contains('civics') || q.contains('नागरिक शास्त्र')) {
    return 'Civics में संविधान, लोकतंत्र, सरकार, नागरिक अधिकार और जिम्मेदारियों का अध्ययन किया जाता है।';
  }
  if (q.contains('economics') || q.contains('अर्थशास्त्र')) {
    return 'Economics में संसाधनों, उत्पादन, बाजार, आय, कीमत और आर्थिक गतिविधियों का अध्ययन किया जाता है।';
  }
  return null;
}


String? solveComputer(String raw, int classNo, String chapter) {
  final q = raw.toLowerCase().trim();

  final concepts = <String, String>{
    'hardware': 'Hardware कंप्यूटर के वे physical parts हैं जिन्हें हम छू सकते हैं। उदाहरण: keyboard, mouse, monitor, CPU, printer।',
    'software': 'Software instructions/programs का समूह है जो computer को काम करने के लिए निर्देश देता है। उदाहरण: operating system और apps।',
    'cpu': 'CPU (Central Processing Unit) computer के instructions को process करता है। इसे सामान्य रूप से computer का “brain” कहा जाता है।',
    'ram': 'RAM (Random Access Memory) temporary working memory है। इसमें currently चल रहे programs और data अस्थायी रूप से रखे जाते हैं।',
    'rom': 'ROM (Read Only Memory) ऐसी memory है जिसमें data सामान्यतः स्थायी रूप से रखा जाता है और power off होने पर भी बना रहता है।',
    'internet': 'Internet दुनिया भर के connected computers और networks का विशाल network है, जिसके माध्यम से information और services का आदान-प्रदान होता है।',
    'browser': 'Web browser ऐसा software है जिससे websites और web pages खोले और देखे जाते हैं। उदाहरण: Chrome, Firefox, Edge।',
    'url': 'URL (Uniform Resource Locator) web पर किसी resource का address बताता है।',
    'algorithm': 'Algorithm किसी समस्या को हल करने के लिए step-by-step instructions का क्रम है।',
    'variable': 'Programming में variable एक नामित स्थान है जिसमें कोई value/data रखी जा सकती है और program के दौरान उसकी value बदल सकती है।',
    'loop': 'Loop programming में किसी instruction या instructions के समूह को बार-बार चलाने के लिए उपयोग होता है।',
    'html': 'HTML (HyperText Markup Language) web pages की structure बनाने के लिए इस्तेमाल होने वाली markup language है।',
    'cyber safety': 'Cyber safety में strong passwords, privacy protection, suspicious links से सावधानी, software updates और personal information की सुरक्षा शामिल है।',
    'पासवर्ड': 'Strong password लंबा और unique होना चाहिए। अलग-अलग accounts के लिए अलग passwords रखना और OTP/password किसी के साथ share न करना सुरक्षित अभ्यास है।',
    'फिशिंग': 'Phishing एक धोखाधड़ी है जिसमें attacker नकली message, email या website के जरिए password, OTP या अन्य sensitive information लेने की कोशिश करता है।',
    'digital footprint': 'Digital footprint internet पर आपकी activities से बनने वाला information trail है। Post, comment, search या online activity इसका हिस्सा हो सकती है।',
  };

  for (final e in concepts.entries) {
    if (q.contains(e.key)) {
      return '💻 Computer\\n\\n${e.value}\\n\\n'
          '👨‍🏫 Teacher: इस concept को याद रखने के लिए एक real-life example बनाकर सोचें।';
    }
  }

  if (q.contains('input') && q.contains('output')) {
    return 'Input device user से data/instructions लेता है, जबकि output device processed result दिखाता या देता है।\\n\\n'
      'Examples: Keyboard = input, Monitor = output.';
  }

  if (q.contains('operating system') || q.contains('os')) {
    return 'Operating System (OS) वह system software है जो computer के hardware और applications के बीच coordination करता है।';
  }

  if (q.contains('binary')) {
    return 'Binary number system में केवल दो digits होते हैं: 0 और 1। Computers digital information को binary representation में process करते हैं।';
  }

  if (q.contains('coding') || q.contains('programming')) {
    return 'Coding/programming में किसी problem को solve करने के लिए computer-readable instructions लिखी जाती हैं। पहले logic/algorithm समझना, फिर code लिखना आसान रहता है।';
  }

  return null;
}

class AskPage extends StatefulWidget {
  final int classNo; final String subject; final String chapter;
  const AskPage({super.key, required this.classNo, required this.subject, required this.chapter});
  @override State<AskPage> createState() => _AskPageState();
}

class _AskPageState extends State<AskPage> {
  final text = TextEditingController();
  final picker = ImagePicker();
  final speech = stt.SpeechToText();
  final tts = FlutterTts();
  File? photo;
  bool listening = false, scanning = false;
  String status = '';
  String solution = '';

  Future<void> scanPhoto() async {
    final x = await picker.pickImage(source: ImageSource.camera, imageQuality: 85);
    if (x == null) return;
    setState(() { photo = File(x.path); scanning = true; status = 'Photo पढ़ी जा रही है…'; solution = ''; });

    final input = InputImage.fromFilePath(x.path);
    final latinRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
    final devanagariRecognizer = TextRecognizer(script: TextRecognitionScript.devanagiri);
    try {
      final latinResult = await latinRecognizer.processImage(input);
      final devanagariResult = await devanagariRecognizer.processImage(input);
      await latinRecognizer.close();
      await devanagariRecognizer.close();

      final latinText = latinResult.text.trim();
      final hindiText = devanagariResult.text.trim();
      final combined = [hindiText, latinText]
          .where((v) => v.isNotEmpty)
          .join('\\n');

      setState(() {
        scanning = false;
        text.text = combined;
        text.selection = TextSelection.collapsed(offset: text.text.length);
        status = combined.isEmpty
            ? 'सवाल साफ नहीं पढ़ा गया। Photo दोबारा लें या text edit करें।'
            : 'Hindi/English OCR पूरा हुआ। नीचे सवाल check/edit करें, फिर Confirm & Solve दबाएँ।';
      });
    } catch (e) {
      await recognizer.close();
      setState(() {
        scanning = false;
        status = 'OCR अभी इस device पर उपलब्ध नहीं हो पाया। Text manually डाल सकते हैं।';
      });
    }
  }

  Future<void> speakQuestion() async {
    final ok = await speech.initialize();
    if (!ok) {
      setState(() => status = 'Voice recognition इस device पर उपलब्ध नहीं है।');
      return;
    }
    setState(() { listening = true; status = 'बोलिए…'; });
    await speech.listen(
      localeId: 'hi_IN',
      onResult: (r) {
        setState(() {
          text.text = r.recognizedWords;
          text.selection = TextSelection.collapsed(offset: text.text.length);
          if (r.finalResult) {
            listening = false;
            status = 'Voice input पूरा हुआ। अब सवाल check करें।';
          }
        });
      },
    );
  }

  Future<void> stopListening() async {
    await speech.stop();
    setState(() => listening = false);
  }

  Future<void> teacherSpeak() async {
    if (solution.isEmpty) return;
    await tts.setLanguage('hi-IN');
    await tts.setSpeechRate(0.45);
    await tts.speak(solution);
  }

  void solve() {
    final q = text.text.trim();
    if (q.isEmpty) return;
    final dynamic r = widget.subject == 'Mathematics'
        ? solveMath(q)
        : widget.subject == 'Science'
            ? solveScience(q, widget.classNo, widget.chapter)
            : widget.subject == 'Hindi'
                ? solveHindi(q, widget.classNo, widget.chapter)
                : widget.subject == 'English'
                    ? solveEnglish(q, widget.classNo, widget.chapter)
                    : widget.subject == 'Social Science'
                        ? solveSocialScience(q, widget.classNo, widget.chapter)
                        : widget.subject == 'Computer'
                            ? solveComputer(q, widget.classNo, widget.chapter)
                            : null;
    setState(() {
      solution = r ??
          'अभी इस सवाल का local solver उपलब्ध नहीं है। इस subject में chapter-wise knowledge धीरे-धीरे जोड़ी जाएगी।';
      status = '';
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('${widget.chapter} • Teacher')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Text('Class ${widget.classNo} • ${widget.subject}',
        style: const TextStyle(fontWeight: FontWeight.bold)),
      Text(widget.chapter, style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 16),
      if (photo != null) ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.file(photo!, height: 180, fit: BoxFit.cover)),
      if (scanning) const Padding(
        padding: EdgeInsets.symmetric(vertical: 10),
        child: LinearProgressIndicator()),
      const SizedBox(height: 10),
      TextField(
        controller: text, minLines: 3, maxLines: 8,
        decoration: const InputDecoration(
          hintText: 'OCR के बाद सवाल यहाँ check/edit करें',
          border: OutlineInputBorder(), prefixIcon: Icon(Icons.edit))),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: OutlinedButton.icon(
          onPressed: listening ? stopListening : speakQuestion,
          icon: Icon(listening ? Icons.stop : Icons.mic),
          label: Text(listening ? 'Stop' : 'Voice'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton.icon(
          onPressed: scanPhoto, icon: const Icon(Icons.camera_alt), label: const Text('Photo'))),
      ]),
      const SizedBox(height: 10),
      FilledButton.icon(
        onPressed: solve, icon: const Icon(Icons.calculate), label: const Text('Confirm & Solve')),
      if (status.isNotEmpty) Padding(
        padding: const EdgeInsets.only(top: 12),
        child: Text(status, style: const TextStyle(color: Colors.black54))),
      if (solution.isNotEmpty) Card(
        margin: const EdgeInsets.only(top: 18),
        child: Padding(padding: const EdgeInsets.all(16), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('👨‍🏫 Teacher',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(solution, style: const TextStyle(fontSize: 16, height: 1.5)),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: teacherSpeak, icon: const Icon(Icons.volume_up), label: const Text('सुनें')),
          ],
        )),
      ),
    ]),
  );
}

String? solveMath(String raw) {
  final q = raw.toLowerCase().trim().replaceAll(',', '');

  final fraction = _fractionResult(raw);
  if (fraction.isNotEmpty) return fraction;

  final equation = _linearEquation(raw);
  if (equation != null) return equation;

  final speed = _speedDistanceTime(raw);
  if (speed != null) return speed;
  final ar = RegExp(r'^(-?\d+(?:\.\d+)?)\s*([+\-x×*/÷])\s*(-?\d+(?:\.\d+)?)$').firstMatch(q);
  if (ar != null) {
    final a = double.parse(ar.group(1)!);
    final op = ar.group(2)!;
    final b = double.parse(ar.group(3)!);
    if ((op == '/' || op == '÷') && b == 0) return '0 से divide नहीं कर सकते।';
    final v = {'+':a+b,'-':a-b,'x':a*b,'×':a*b,'*':a*b,'/':a/b,'÷':a/b}[op]!;
    final ans = fmt(v);
    return 'उत्तर: $ans\n\nSteps: $a $op $b = $ans\n\n'
      '💡 Trick: ${op == '×' && b == 25 ? '×25 = ×100 ÷ 4' : 'पहले operation पहचानें और calculation करें।'}\n\n'
      'Teacher: चलो धीरे-धीरे करते हैं। $a $op $b करने पर हमें $ans मिलता है।';
  }
  final p = RegExp(r'(-?\d+(?:\.\d+)?)\s*%\s*(?:of|का|के|की)?\s*(-?\d+(?:\.\d+)?)').firstMatch(q);
  if (p != null) {
    final percent = double.parse(p.group(1)!);
    final n = double.parse(p.group(2)!);
    final v = percent*n/100;
    final ans = fmt(v);
    return 'उत्तर: $ans\n\nSteps: ($percent ÷ 100) × $n = $ans\n\n'
      '💡 Trick: ${percent == 25 ? '25% = 1/4, इसलिए संख्या को 4 से divide करें।'
      : percent == 50 ? '50% = 1/2, इसलिए आधा लें।'
      : 'Percentage को fraction में बदलें।'}\n\n'
      'Teacher: पहले percentage को fraction बनाते हैं, फिर संख्या से multiply करते हैं।';
  }
  return null;
}

String fmt(double x) => x == x.roundToDouble()
  ? x.toInt().toString()
  : x.toStringAsFixed(2).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
